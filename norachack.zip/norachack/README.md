#NoracIV
----------


#install
----------
pkg install python2

pkg install python2-dev

pkg install pip2

pip2 install mechanize

pkg install git

git clone https://github.com/NoracDedsec/norachack

#Ejecuted
----------
cd norachack

chmod +x hack.py

python2 hack.py

